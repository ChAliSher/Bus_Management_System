package bus.management.system;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

public class conn {

    private Connection connection;
    Statement statement;

    public conn() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_management", "root", "AliSher12");
            statement = connection.createStatement();
            System.out.println("Connected to local database!");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to connect to local database!");
        }
    }

    public static void main(String[] args) {
        new conn();
    }
}