package bus.management.system;

import javax.swing.*;
import java.awt.*;

public class Splash extends JFrame {

    Splash() {
        super("Bus Management System (Developed by Ahmar)");

        // Create a custom font with a unique style for the title
        Font titleFont = new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 36);

        // JLabel for the title
        JLabel titleLabel = new JLabel("<< Bus Management System >>", SwingConstants.CENTER);
        titleLabel.setFont(titleFont);
        titleLabel.setBounds(0, 300, 1200, 50); // Adjusted bounds for the larger frame
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        // ImageIcon for the logo
        ImageIcon logoIcon = new ImageIcon(ClassLoader.getSystemResource("icons/boom.gif"));
        Image scaledLogo = logoIcon.getImage().getScaledInstance(1200, 700, Image.SCALE_DEFAULT); // Adjusted size
        ImageIcon scaledIcon = new ImageIcon(scaledLogo);
        JLabel logoLabel = new JLabel(scaledIcon);
        logoLabel.setBounds(0, 0, 1200, 700); // Adjusted bounds for the larger frame
        add(logoLabel);

        setSize(1200, 700); // Adjusted frame size
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        try {
            Thread.sleep(3000);
            setVisible(false);
            Login login = new Login();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Splash();
    }
}
