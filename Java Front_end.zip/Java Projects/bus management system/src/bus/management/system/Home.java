package bus.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame implements ActionListener {

    private final JButton addBusButton, addTravellerButton, generateReportButton;
    private final JLabel backgroundLabel, titleLabel;
    private final JButton exitButton;

    Home() {
        super("Bus Management System");

        titleLabel = new JLabel("HOME");
        titleLabel.setBounds(545, 30, 300, 50);
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        addBusButton = new JButton("Add Bus");
        addBusButton.setBounds(500, 200, 200, 50);
        addBusButton.setBackground(new Color(18, 117, 173));
        addBusButton.setForeground(Color.lightGray);
        addBusButton.addActionListener(this);
        add(addBusButton);

        addTravellerButton = new JButton("Add Traveller");
        addTravellerButton.setBounds(500, 300, 200, 50);
        addTravellerButton.setBackground(new Color(18, 117, 173));
        addTravellerButton.setForeground(Color.lightGray);
        addTravellerButton.addActionListener(this);
        add(addTravellerButton);

        generateReportButton = new JButton("View Details");
        generateReportButton.setBounds(500, 400, 200, 50);
        generateReportButton.setBackground(new Color(18, 117, 173));
        generateReportButton.setForeground(Color.lightGray);
        generateReportButton.addActionListener(this);
        add(generateReportButton);

        exitButton = new JButton(("EXIT"));
        exitButton.setBounds(70, 600, 170, 27);
        exitButton.setBackground(new Color(70,130,180));
        exitButton.setForeground(Color.BLACK);
        exitButton.addActionListener(this);
        add(exitButton);

        // Background image
        ImageIcon backgroundImage = new ImageIcon(ClassLoader.getSystemResource("icons/desk.jpg"));
        Image scaledBackground = backgroundImage.getImage().getScaledInstance(1200, 700, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(scaledBackground);
        backgroundLabel = new JLabel(scaledIcon);
        backgroundLabel.setBounds(0, 0, 1200, 700);
        add(backgroundLabel);

        setSize(1200, 700);
        setLocation(160, 55);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == exitButton) {
            System.out.println("Back Button Clicked! Ending Program...");
            JOptionPane.showMessageDialog(null, "Program Ending!");
            System.exit(0);
        } else if (e.getSource() == addBusButton) {
            System.out.println("Add Bus Button clicked! Redirecting...");
            setVisible(false);
            AddBus bus = new AddBus();
        } else if (e.getSource() == addTravellerButton) {
            System.out.println("Add Traveller Button clicked! Redirecting...");
            setVisible(false);
            AddTraveller traveller = new AddTraveller();
        }else if(e.getSource() == generateReportButton){
            System.out.println("View Details Button clicked! Redirecting...");
            setVisible(false);
            ViewRecords details = new ViewRecords();
        }
    }

    public static void main(String[] args) {
        new Home();
    }
}
