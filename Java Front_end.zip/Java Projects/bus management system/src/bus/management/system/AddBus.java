package bus.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;

public class AddBus extends JFrame implements ActionListener {

    private final JTextField busNumberField, capacityField;
    private final JButton addButton, backButton;
    private final JLabel busNumberLabel, capacityLabel, backgroundLabel;

    private Connection connection;

    AddBus() {
        super("Add Bus");

        // Create labels
        busNumberLabel = new JLabel("Bus Number:");
        busNumberLabel.setBounds(400, 200, 150, 30);
        busNumberLabel.setForeground(Color.WHITE);
        add(busNumberLabel);

        capacityLabel = new JLabel("Capacity:");
        capacityLabel.setBounds(400, 250, 150, 30);
        capacityLabel.setForeground(Color.WHITE);
        add(capacityLabel);

        // Create text fields
        busNumberField = new JTextField();
        busNumberField.setBounds(550, 200, 200, 30);
        add(busNumberField);

        capacityField = new JTextField();
        capacityField.setBounds(550, 250, 200, 30);
        add(capacityField);

        // Create buttons
        addButton = new JButton("Add");
        addButton.setBounds(450, 350, 100, 30);
        addButton.setBackground(new Color(18, 117, 173));
        addButton.setForeground(Color.WHITE);
        addButton.addActionListener(this);
        add(addButton);

        backButton = new JButton("Back");
        backButton.setBounds(600, 350, 100, 30);
        backButton.setBackground(new Color(18, 117, 173));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(this);
        add(backButton);

        // Background image
        ImageIcon backgroundImage = new ImageIcon(ClassLoader.getSystemResource("icons/desk.jpg"));
        Image scaledBackground = backgroundImage.getImage().getScaledInstance(1200, 700, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(scaledBackground);
        backgroundLabel = new JLabel(scaledIcon);
        backgroundLabel.setBounds(0, 0, 1200, 700);
        add(backgroundLabel);

        setSize(1200, 700);
        setLocation(160, 55);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            // Add bus to the database
            conn connection = new conn();
            String busNumber = busNumberField.getText();
            int capacity = Integer.parseInt(capacityField.getText());

            try {
                String query = "INSERT INTO buses (bus_number, capacity) VALUES ('"+busNumber+"', '"+capacity+"')";
                connection.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Employee Added Successfully!");
                setVisible(false);
                new Home();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == backButton) {
            // Go back to the home page
            new Home();
            this.dispose();
        }
    }

    public static void main(String[] args) {
        new AddBus();
    }
}
