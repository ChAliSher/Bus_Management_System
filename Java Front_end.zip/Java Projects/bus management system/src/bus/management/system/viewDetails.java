package bus.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

    class ViewRecords extends JFrame implements ActionListener {

    private final Choice choice;
    private final JScrollPane jScrollPane;
    private final JTable table;
    private final JLabel searchLabel, titleLabel, backgroundLabel;
    private final JButton searchButton, printButton, backButton;
    private ResultSet resultSet;

    public ViewRecords() {
        super("View Records Portal");

        // Create labels
        titleLabel = new JLabel("View Records Portal");
        titleLabel.setBounds(470, 30, 300, 50);
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        searchLabel = new JLabel("Select Record:");
        searchLabel.setBounds(80, 100, 150, 30);
        searchLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        searchLabel.setForeground(Color.WHITE);
        add(searchLabel);

        // Create choice for record type
        choice = new Choice();
        choice.setBounds(250, 100, 200, 30);
        choice.add("Buses");
        choice.add("Passengers");
        add(choice);

        // Create table to display records
        table = new JTable();
        jScrollPane = new JScrollPane(table);
        jScrollPane.setBounds(100, 200, 1000, 300);
        add(jScrollPane);

        // Create buttons
        searchButton = new JButton("SEARCH");
        searchButton.setBounds(500, 550, 150, 30);
        searchButton.setBackground(new Color(18, 117, 173));
        searchButton.setForeground(Color.WHITE);
        searchButton.addActionListener(this);
        add(searchButton);

        printButton = new JButton("PRINT");
        printButton.setBounds(300, 550, 150, 30);
        printButton.setBackground(new Color(18, 117, 173));
        printButton.setForeground(Color.WHITE);
        printButton.addActionListener(this);
        add(printButton);

        backButton = new JButton("BACK");
        backButton.setBounds(700, 550, 150, 30);
        backButton.setBackground(new Color(18, 117, 173));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(this);
        add(backButton);

        // Background image
        ImageIcon backgroundImage = new ImageIcon(ClassLoader.getSystemResource("icons/desk.jpg"));
        Image scaledBackground = backgroundImage.getImage().getScaledInstance(1200, 700, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(scaledBackground);
        backgroundLabel = new JLabel(scaledIcon);
        backgroundLabel.setBounds(0, 0, 1200, 700);
        add(backgroundLabel);

        setSize(1200, 700);
        setLocationRelativeTo(null);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == searchButton) {
            String recordType = choice.getSelectedItem();
            String query = "";
            if (recordType.equals("Buses")) {
                query = "SELECT * FROM buses;";
            } else if (recordType.equals("Passengers")) {
                query = "SELECT * FROM travellers;";
            }

            try {
                conn connection = new conn();
                resultSet = connection.statement.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(resultSet));
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == printButton) {
            try {
                table.print();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == backButton) {
            setVisible(false);
            new Home();
        }
    }

    public static void main(String[] args) {
        new ViewRecords();
    }
}
