package bus.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

public class AddTraveller extends JFrame implements ActionListener {

    private final JTextField nameField, ageField, emailField, cnicField, phoneField;
    private final JButton addButton, backButton;
    private final JLabel nameLabel, ageLabel, emailLabel, cnicLabel, phoneLabel, backgroundLabel;

    AddTraveller() {
        super("Add Traveller");

        // Create labels
        nameLabel = new JLabel("Name:");
        nameLabel.setBounds(400, 100, 150, 30);
        nameLabel.setForeground(Color.WHITE);
        add(nameLabel);

        ageLabel = new JLabel("Age:");
        ageLabel.setBounds(400, 150, 150, 30);
        ageLabel.setForeground(Color.WHITE);
        add(ageLabel);

        emailLabel = new JLabel("Email:");
        emailLabel.setBounds(400, 200, 150, 30);
        emailLabel.setForeground(Color.WHITE);
        add(emailLabel);

        cnicLabel = new JLabel("CNIC:");
        cnicLabel.setBounds(400, 250, 150, 30);
        cnicLabel.setForeground(Color.WHITE);
        add(cnicLabel);

        phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(400, 300, 150, 30);
        phoneLabel.setForeground(Color.WHITE);
        add(phoneLabel);

        // Create text fields
        nameField = new JTextField();
        nameField.setBounds(550, 100, 200, 30);
        add(nameField);

        ageField = new JTextField();
        ageField.setBounds(550, 150, 200, 30);
        add(ageField);

        emailField = new JTextField();
        emailField.setBounds(550, 200, 200, 30);
        add(emailField);

        cnicField = new JTextField();
        cnicField.setBounds(550, 250, 200, 30);
        add(cnicField);

        phoneField = new JTextField();
        phoneField.setBounds(550, 300, 200, 30);
        add(phoneField);

        // Create buttons
        addButton = new JButton("Add");
        addButton.setBounds(450, 400, 100, 30);
        addButton.setBackground(new Color(18, 117, 173));
        addButton.setForeground(Color.WHITE);
        addButton.addActionListener(this);
        add(addButton);

        backButton = new JButton("Back");
        backButton.setBounds(600, 400, 100, 30);
        backButton.setBackground(new Color(18, 117, 173));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(this);
        add(backButton);

        // Background image
        ImageIcon backgroundImage = new ImageIcon(ClassLoader.getSystemResource("icons/desk.jpg"));
        Image scaledBackground = backgroundImage.getImage().getScaledInstance(1200, 700, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(scaledBackground);
        backgroundLabel = new JLabel(scaledIcon);
        backgroundLabel.setBounds(0, 0, 1200, 700);
        add(backgroundLabel);

        setSize(1200, 700);
        setLocation(160, 55);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            // Add traveller to the database
            String name = nameField.getText();
            int age = Integer.parseInt(ageField.getText());
            String email = emailField.getText();
            String cnic = cnicField.getText();
            String phone = phoneField.getText();

            try {
                conn connection = new conn();
                String query = "INSERT INTO travellers (name, age, email, cnic, phone) VALUES ('"+name+"', '"+age+"', '"+email+"', '"+cnic+"', '"+phone+"')";
                connection.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Passenger Added Successfully!");
                setVisible(false);
                new Home();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == backButton) {
            // Go back to the home page
            new Home();
            this.dispose();
        }
    }

    public static void main(String[] args) {
        new AddTraveller();
    }
}
