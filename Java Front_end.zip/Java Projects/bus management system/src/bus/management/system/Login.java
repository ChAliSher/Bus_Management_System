package bus.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {

    private final JTextField user;
    private final JPasswordField pass;
    private final JButton loginButton, exitButton;
    private String sUsername, sPassword, query;
    private final JLabel username, password;
    private conn con;
    private ResultSet result;

    Login() {

        super("Bus Management System");

        username = new JLabel("USERNAME:");
        username.setBounds(100, 80, 160, 80);
        username.setForeground(Color.WHITE);
        add(username);

        user = new JTextField();
        user.setForeground(Color.BLACK);
        user.setBackground(Color.WHITE);
        user.setBounds(185, 108, 170, 25);
        user.setBorder(null);
        user.setOpaque(true);
        user.setHorizontalAlignment(JTextField.CENTER);
        add(user);

        password = new JLabel("PASSWORD:");
        password.setBounds(100, 120, 160, 80);
        password.setForeground(Color.WHITE);
        add(password);

        pass = new JPasswordField();
        pass.setForeground(Color.BLACK);
        pass.setBackground(Color.WHITE);
        pass.setBounds(185, 148, 170, 25);
        pass.setBorder(null);
        pass.setOpaque(true);
        pass.setHorizontalAlignment(JTextField.CENTER);
        add(pass);

        loginButton = new JButton("LOGIN");
        loginButton.setBounds(885, 105, 170, 27);
        loginButton.setBackground(new Color(18, 117, 173));
        loginButton.setForeground(Color.lightGray);
        loginButton.addActionListener(this);
        add(loginButton);

        exitButton = new JButton(("EXIT"));
        exitButton.setBounds(70, 600, 170, 27);
        exitButton.setBackground(new Color(70,130,180));
        exitButton.setForeground(Color.BLACK);
        exitButton.addActionListener(this);
        add(exitButton);

        ImageIcon logoIcon = new ImageIcon(ClassLoader.getSystemResource("icons/desk.jpg"));
        Image scaledLogo = logoIcon.getImage().getScaledInstance(1200, 700, Image.SCALE_DEFAULT); // Adjusted size
        ImageIcon scaledIcon = new ImageIcon(scaledLogo);
        JLabel logoLabel = new JLabel(scaledIcon);
        logoLabel.setBounds(0, 0, 1200, 700); // Adjusted bounds for the larger frame
        add(logoLabel);

        setSize(1200, 700); // size of frame.
        setLocation(160, 55); // location on screen where frame opens.
        setLayout(null); // bcz we want to set our layout custom to needs.
        setVisible(true); // by default frame is hidden.
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {

            try {
                sUsername = user.getText();
                sPassword = pass.getText();

                con = new conn();
                query = "SELECT * FROM login WHERE username = '" + sUsername + "' AND password = '" + sPassword + "'";
                result = con.statement.executeQuery(query);

                if(result.next()) {
                    setVisible(false);
                    Home homeScreen = new Home();
                }else {
                    JOptionPane.showMessageDialog(null, "Invalid Username or Password! Contact DBS Manager if you forgot the login details.");
                }

            } catch(Exception exx) {
                exx.printStackTrace();
            }

        }else {
            System.out.println("Back Button Clicked! Ending Program...");
            JOptionPane.showMessageDialog(null, "Program Ending!");
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}